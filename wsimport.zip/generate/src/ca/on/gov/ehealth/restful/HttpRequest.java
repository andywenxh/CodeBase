
package ca.on.gov.ehealth.restful;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Method" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ServiceURI" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="IsMultiplePart" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="Boundary" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element ref="{http://ehealth.gov.on.ca/restful}Headers"/&gt;
 *         &lt;element ref="{http://ehealth.gov.on.ca/restful}MessagePart" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "method",
    "serviceURI",
    "isMultiplePart",
    "boundary",
    "headers",
    "messagePart"
})
@XmlRootElement(name = "HttpRequest")
public class HttpRequest {

    @XmlElement(name = "Method", required = true)
    protected String method;
    @XmlElement(name = "ServiceURI", required = true)
    protected String serviceURI;
    @XmlElement(name = "IsMultiplePart", defaultValue = "false")
    protected boolean isMultiplePart;
    @XmlElement(name = "Boundary", required = true, nillable = true)
    protected String boundary;
    @XmlElement(name = "Headers", required = true)
    protected Headers headers;
    @XmlElement(name = "MessagePart")
    protected List<MessagePart> messagePart;

    /**
     * Gets the value of the method property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMethod() {
        return method;
    }

    /**
     * Sets the value of the method property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMethod(String value) {
        this.method = value;
    }

    /**
     * Gets the value of the serviceURI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceURI() {
        return serviceURI;
    }

    /**
     * Sets the value of the serviceURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceURI(String value) {
        this.serviceURI = value;
    }

    /**
     * Gets the value of the isMultiplePart property.
     * 
     */
    public boolean isIsMultiplePart() {
        return isMultiplePart;
    }

    /**
     * Sets the value of the isMultiplePart property.
     * 
     */
    public void setIsMultiplePart(boolean value) {
        this.isMultiplePart = value;
    }

    /**
     * Gets the value of the boundary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBoundary() {
        return boundary;
    }

    /**
     * Sets the value of the boundary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBoundary(String value) {
        this.boundary = value;
    }

    /**
     * Gets the value of the headers property.
     * 
     * @return
     *     possible object is
     *     {@link Headers }
     *     
     */
    public Headers getHeaders() {
        return headers;
    }

    /**
     * Sets the value of the headers property.
     * 
     * @param value
     *     allowed object is
     *     {@link Headers }
     *     
     */
    public void setHeaders(Headers value) {
        this.headers = value;
    }

    /**
     * Gets the value of the messagePart property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the messagePart property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMessagePart().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MessagePart }
     * 
     * 
     */
    public List<MessagePart> getMessagePart() {
        if (messagePart == null) {
            messagePart = new ArrayList<MessagePart>();
        }
        return this.messagePart;
    }

}
