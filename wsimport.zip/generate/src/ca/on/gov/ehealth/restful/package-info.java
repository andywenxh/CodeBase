/**
 * HRM Publisher Restful Service, @version V1.0, @date 2016-12
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://ehealth.gov.on.ca/restful", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ca.on.gov.ehealth.restful;
