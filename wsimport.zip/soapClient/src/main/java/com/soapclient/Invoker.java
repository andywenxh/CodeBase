package com.soapclient;

import ca.on.gov.ehealth.restful.*;

import java.net.URL;

public class Invoker {


 public static void main(String[] str) throws Exception{

     URL wsdlLocation = new URL("http://127.0.0.1:8080/soap?wsdl");
     HRMPublisherService service = new HRMPublisherService(wsdlLocation);
     HRMPublisherServicePortType port = service.getHRMPublisherServiceDefaultPort();

     RestfulRequest request = new RestfulRequest();
     HttpRequest httpRequest = new HttpRequest();
     request.setCertDN("CN=123");
     request.setHttpRequest(httpRequest);

     httpRequest.setMethod("POST");
     httpRequest.setServiceURI("http://localhost:8080/soap");
     httpRequest.setIsMultiplePart(false);


     MessagePart messagePart = new MessagePart();
     httpRequest.getMessagePart().add( messagePart );
     messagePart.setMessageContent("hello");
     Header header = new Header();
     header.setKey("client-id");
     header.setValue("123sadc2-ldl2");

     Headers headers = new Headers();
     headers.getHeader().add( header);
     messagePart.setHeaders( headers );

     httpRequest.getMessagePart().add(messagePart);

     httpRequest.setHeaders( new Headers());
     Header header2 = new Header();
     header2.setKey("client-id");
     header2.setValue("123sadc2-ldl2");
     httpRequest.getHeaders().getHeader().add(header2);

     RestfulResponse response = port.hrmPublisherRestfulOperation( request );
     System.out.println( response );

 }

}
