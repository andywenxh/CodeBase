package com.eho.util;

public class CertHash {

	public static void main(String[] args) throws Exception {
		KeyContext ctx = KeyManager.getKeyCtx(args[0], "Keys04QA");		
	}
	
	
	

}
