package com.eho.pcis.beans;

public class Source {

	String source = "";

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}	
}
