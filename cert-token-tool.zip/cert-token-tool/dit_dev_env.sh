#!/bin/sh
export REALM=provider/default-idp-2
export USERNAME=pcis
export PASSWORD=Pcis123#
export OAG_MGR=ontapid0bav002.subscribers.ssh
export OAG_ORG=dev
export OAG_CATALOG=fhir
export OAG_SPACE=olis-c
export OAG_GATEWAY=consumer1
export OAG_CORG=developer
export OAG_APPNAME=unittestapp