context.set('message.headers.GtwyErrorCode', errorCode.ref_code);
context.set('message.headers.GtwyTxId', context.get('GtwyTxId'));

